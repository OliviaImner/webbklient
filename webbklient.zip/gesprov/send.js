//Funktion för när användare trycker på skicka knappen på kontaktsidan. Det kommer inte att skickas något men du får en feedback. 

function send() {
	alert("Tack för ditt meddelande.");
}